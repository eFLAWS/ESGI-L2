# api-partiel

Partiel WEB-API

Le login/logout, hashage du MDP ne sont pas implémentés.
